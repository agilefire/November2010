using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Demo.SOLID
{

    public abstract class ReportPrinter
    {
        public abstract void Print();
    }
}