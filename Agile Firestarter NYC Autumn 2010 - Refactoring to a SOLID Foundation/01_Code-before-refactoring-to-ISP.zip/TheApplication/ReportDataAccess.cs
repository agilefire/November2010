using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Demo.SOLID
{

    public class ReportDataAccess : IDataAccess
    {
        public IList<DataElement> GetReportData()
        {
            Console.WriteLine("\nGetting Data from database...");
            return new List<DataElement>();
        }

        public IList<DataElement> QueryData(string criteria)
        {
            throw new NotImplementedException();
        }

        public void SaveData(DataElement dataElement)
        {
            throw new NotImplementedException();
        }

    }
}
