using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Demo.SOLID
{
     public class LaserReportPrinter : ReportPrinter
    {
        public override void Print()
        {
            ReportDataAccess dataAccess = new ReportDataAccess();
            LetterReportFormatter reportFormatter = new LetterReportFormatter();
            dataAccess.GetReportData();
            reportFormatter.FormatReport();
            Console.WriteLine("\nPrinting Report to laser printer...");
        }
    }
}
