using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Demo.SOLID
{

    public interface IDataAccess
    {
        void SaveData(DataElement dataElement);
        IList<DataElement> QueryData(string criteria);
        IList<DataElement> GetReportData();
    }

}
