using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Demo.SOLID
{
    public class DataElement
    {
        public string CustomerFirstname { get; set; }
        public string CustomerLastname { get; set; }
    }
}
